"""
main.py
=======
Entry point for the Agile Delivery Intelligence Engine prototype.

    Python Script (Engine)  ──JQL Query──▶  Jira API
                            ◀─Raw JSON────
    Python Script (Engine)  ──System Prompt + Data──▶  LLM API (OpenAI)
                            ◀─Automated Text Report──

Usage:
    python main.py --mode standup
    python main.py --mode weekly  --output reports/weekly.md
    python main.py --mode retro   --no-webhook
"""

from __future__ import annotations

import argparse
import logging
import os
import sys
from datetime import datetime
from pathlib import Path

import requests
import yaml
from dotenv import load_dotenv

from jira_client import JiraAPIError, JiraClient
from llm_engine import generate_report
from transformer import build_payload

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s | %(levelname)-7s | %(name)s | %(message)s",
)
logger = logging.getLogger("jira_ai_engine.main")


def load_config(path: str = "config.yaml") -> dict:
    with open(path, "r") as f:
        return yaml.safe_load(f)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Agile Delivery Intelligence Engine")
    parser.add_argument(
        "--mode",
        choices=["standup", "weekly", "retro"],
        default="standup",
        help="Which report to generate: standup (Mode A), weekly (Mode B), retro (Mode C).",
    )
    parser.add_argument("--config", default="config.yaml", help="Path to config.yaml")
    parser.add_argument("--output", default=None, help="Override output file path")
    parser.add_argument(
        "--no-webhook", action="store_true", help="Skip posting to CHAT_WEBHOOK_URL even if configured"
    )
    parser.add_argument(
        "--dry-run",
        action="store_true",
        help="Fetch + transform Jira data and print the payload, but skip the LLM call",
    )
    return parser.parse_args()


def post_to_webhook(report_text: str, webhook_url: str) -> None:
    try:
        resp = requests.post(webhook_url, json={"text": report_text}, timeout=15)
        resp.raise_for_status()
        logger.info("Report posted to chat webhook.")
    except requests.RequestException as exc:
        logger.warning("Failed to post report to webhook: %s", exc)


def main() -> int:
    load_dotenv()
    args = parse_args()
    config = load_config(args.config)

    jira_base_url = os.environ.get("JIRA_BASE_URL")
    jira_email = os.environ.get("JIRA_EMAIL")
    jira_token = os.environ.get("JIRA_API_TOKEN")
    openai_key = os.environ.get("OPENAI_API_KEY")

    missing = [
        name
        for name, val in [
            ("JIRA_BASE_URL", jira_base_url),
            ("JIRA_EMAIL", jira_email),
            ("JIRA_API_TOKEN", jira_token),
            ("OPENAI_API_KEY", openai_key if not args.dry_run else "skip-check"),
        ]
        if not val
    ]
    if missing:
        logger.error("Missing required environment variables: %s (copy .env.example to .env)", missing)
        return 1

    jira_cfg = config["jira"]

    client = JiraClient(base_url=jira_base_url, email=jira_email, api_token=jira_token)

    # ── 1. JQL Query → Jira API → Raw JSON ─────────────────────────────
    logger.info("Fetching issues via JQL: %s", jira_cfg["jql"])
    try:
        raw_issues = client.search_issues(
            jql=jira_cfg["jql"],
            fields=jira_cfg["fields"],
            page_size=jira_cfg.get("page_size", 100),
            include_changelog=jira_cfg.get("include_changelog", True),
        )
        versions_by_project = client.get_project_versions_bulk(config.get("release_projects", []))
    except JiraAPIError as exc:
        logger.error("Jira request failed: %s", exc)
        return 1

    logger.info("Pulled %d issues across %d project(s).", len(raw_issues), len(versions_by_project))

    # ── 2. Package raw data into the schema the system prompt expects ──
    payload = build_payload(
        raw_issues=raw_issues,
        versions_by_project=versions_by_project,
        velocity_config=config.get("team_velocities", {}),
        story_points_field=jira_cfg["story_points_field"],
        team_field=jira_cfg.get("team_field"),
    )

    if args.dry_run:
        import json

        print(json.dumps(payload, indent=2, default=str))
        return 0

    # ── 3. System Prompt + Raw Data → LLM API ───────────────────────────
    llm_cfg = config["llm"]
    try:
        report_text = generate_report(
            mode=args.mode,
            payload=payload,
            api_key=openai_key,
            model=llm_cfg.get("model", "gpt-4.1"),
            temperature=llm_cfg.get("temperature", 0.3),
            max_output_tokens=llm_cfg.get("max_output_tokens", 2000),
        )
    except Exception as exc:  # noqa: BLE001 — surface any LLM/network failure clearly
        logger.error("LLM report generation failed: %s", exc)
        return 1

    # ── 4. Automated Text Report / Alert ────────────────────────────────
    out_cfg = config.get("output", {})
    save_dir = Path(args.output).parent if args.output else Path(out_cfg.get("save_dir", "./reports"))
    save_dir.mkdir(parents=True, exist_ok=True)

    if args.output:
        out_path = Path(args.output)
    else:
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        out_path = save_dir / f"{args.mode}_{timestamp}.md"

    out_path.write_text(report_text, encoding="utf-8")
    logger.info("Report written to %s", out_path)

    print("\n" + "=" * 70)
    print(report_text)
    print("=" * 70 + "\n")

    webhook_url = os.environ.get("CHAT_WEBHOOK_URL")
    if webhook_url and out_cfg.get("post_to_webhook", True) and not args.no_webhook:
        post_to_webhook(report_text, webhook_url)

    return 0


if __name__ == "__main__":
    sys.exit(main())
