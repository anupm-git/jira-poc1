"""
transformer.py
===============
Converts raw, noisy Jira JSON (issues + changelog + versions) into the four
structured arrays the Agile Delivery Intelligence system prompt expects:

  - Sprint Backlog Snapshot
  - Link Matrix
  - Issue History Logs
  - Release Deadlines & Team Velocities

No Jira- or OpenAI-specific I/O happens here — pure data shaping — so it's
straightforward to unit test with fixture JSON.
"""

from __future__ import annotations

from typing import Any, Dict, List, Optional


def _safe_get(d: Optional[Dict], *path, default=None):
    cur = d
    for p in path:
        if not isinstance(cur, dict):
            return default
        cur = cur.get(p)
        if cur is None:
            return default
    return cur


def _extract_team(fields: Dict[str, Any], team_field: Optional[str]) -> str:
    if team_field:
        val = fields.get(team_field)
        if isinstance(val, dict):
            return val.get("value") or val.get("name") or "Unassigned Team"
        if isinstance(val, list) and val:
            first = val[0]
            return first.get("value") if isinstance(first, dict) else str(first)
        if isinstance(val, str) and val:
            return val
    # Fallback: use the first component as a proxy for team ownership.
    components = fields.get("components") or []
    if components:
        return components[0].get("name", "Unassigned Team")
    return "Unassigned Team"


# ----------------------------------------------------------------------
# 1. Sprint Backlog Snapshot
# ----------------------------------------------------------------------
def build_backlog_snapshot(
    raw_issues: List[Dict[str, Any]], story_points_field: str, team_field: Optional[str]
) -> List[Dict[str, Any]]:
    snapshot = []
    for issue in raw_issues:
        fields = issue.get("fields", {})
        remaining_seconds = _safe_get(fields, "timetracking", "remainingEstimateSeconds")
        snapshot.append(
            {
                "key": issue.get("key"),
                "summary": fields.get("summary"),
                "issue_type": _safe_get(fields, "issuetype", "name"),
                "status": _safe_get(fields, "status", "name"),
                "status_category": _safe_get(fields, "status", "statusCategory", "key"),
                "priority": _safe_get(fields, "priority", "name"),
                "story_points": fields.get(story_points_field),
                "assignee": _safe_get(fields, "assignee", "displayName", default="Unassigned"),
                "team": _extract_team(fields, team_field),
                "project_key": _safe_get(fields, "project", "key"),
                "labels": fields.get("labels", []),
                "fix_versions": [v.get("name") for v in fields.get("fixVersions", [])],
                "due_date": fields.get("duedate"),
                "remaining_estimate_hours": round(remaining_seconds / 3600, 2)
                if remaining_seconds
                else None,
                "flagged": bool(fields.get("flagged") or _safe_get(fields, "customfield_10021")),
            }
        )
    return snapshot


# ----------------------------------------------------------------------
# 2. Link Matrix (dependency graph)
# ----------------------------------------------------------------------
def build_link_matrix(raw_issues: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    links = []
    for issue in raw_issues:
        source_key = issue.get("key")
        for link in issue.get("fields", {}).get("issuelinks", []):
            link_type = _safe_get(link, "type", "name")
            if "outwardIssue" in link:
                target = link["outwardIssue"]
                direction = "outward"
                relation = _safe_get(link, "type", "outward")
            elif "inwardIssue" in link:
                target = link["inwardIssue"]
                direction = "inward"
                relation = _safe_get(link, "type", "inward")
            else:
                continue
            links.append(
                {
                    "source": source_key,
                    "target": target.get("key"),
                    "target_summary": _safe_get(target, "fields", "summary"),
                    "target_status": _safe_get(target, "fields", "status", "name"),
                    "link_type": link_type,
                    "relation": relation,
                    "direction": direction,
                }
            )
    return links


# ----------------------------------------------------------------------
# 3. Issue History Logs (transitions + blocker flag timestamps)
# ----------------------------------------------------------------------
def build_issue_history(raw_issues: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    history_logs = []
    for issue in raw_issues:
        key = issue.get("key")
        changelog = _safe_get(issue, "changelog", "histories", default=[]) or []

        transitions = []
        blocker_flag_timestamp = None
        blocker_cleared_timestamp = None

        # Chronological order — Jira returns changelog newest-first by default.
        for entry in sorted(changelog, key=lambda h: h.get("created", "")):
            created = entry.get("created")
            for item in entry.get("items", []):
                field = item.get("field")

                if field == "status":
                    transitions.append(
                        {
                            "timestamp": created,
                            "from_status": item.get("fromString"),
                            "to_status": item.get("toString"),
                        }
                    )

                # "Flagged" is Jira's standard impediment field; toString
                # contains "Impediment" when raised and is empty when cleared.
                if field in ("Flagged", "flagged"):
                    if item.get("toString"):
                        blocker_flag_timestamp = created
                    else:
                        blocker_cleared_timestamp = created

        history_logs.append(
            {
                "key": key,
                "transitions": transitions,
                "blocker_flag_timestamp": blocker_flag_timestamp,
                "blocker_cleared_timestamp": blocker_cleared_timestamp,
                "currently_blocked": blocker_flag_timestamp is not None
                and (
                    blocker_cleared_timestamp is None
                    or blocker_cleared_timestamp < blocker_flag_timestamp
                ),
            }
        )
    return history_logs


# ----------------------------------------------------------------------
# 4. Release Deadlines & Team Velocities
# ----------------------------------------------------------------------
def build_release_deadlines(versions_by_project: Dict[str, List[Dict[str, Any]]]) -> List[Dict[str, Any]]:
    deadlines = []
    for project_key, versions in versions_by_project.items():
        for v in versions:
            if v.get("released"):
                continue  # only forward-looking releases matter for risk math
            deadlines.append(
                {
                    "project_key": project_key,
                    "version_name": v.get("name"),
                    "release_date": v.get("releaseDate"),
                    "overdue": v.get("overdue", False),
                }
            )
    return deadlines


def build_team_velocities(velocity_config: Dict[str, Any]) -> Dict[str, Any]:
    # Passed straight through from config.yaml today; swap in a live call
    # to /rest/agile/1.0/board/{id}/velocity here if your Jira plan exposes it.
    return {
        "default_velocity": velocity_config.get("default", 25),
        "teams": velocity_config.get("teams", {}),
    }


# ----------------------------------------------------------------------
# Orchestration entrypoint
# ----------------------------------------------------------------------
def build_payload(
    raw_issues: List[Dict[str, Any]],
    versions_by_project: Dict[str, List[Dict[str, Any]]],
    velocity_config: Dict[str, Any],
    story_points_field: str,
    team_field: Optional[str],
) -> Dict[str, Any]:
    return {
        "sprint_backlog_snapshot": build_backlog_snapshot(raw_issues, story_points_field, team_field),
        "link_matrix": build_link_matrix(raw_issues),
        "issue_history_logs": build_issue_history(raw_issues),
        "release_deadlines": build_release_deadlines(versions_by_project),
        "team_velocities": build_team_velocities(velocity_config),
    }
