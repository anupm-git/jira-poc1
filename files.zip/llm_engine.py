"""
llm_engine.py
=============
Packages the transformed Jira payload with the system prompt and sends it
to the LLM. Uses the official `openai` Python library as the reference
implementation — swap the client in `_call_openai` for Anthropic/Azure/etc.
without touching main.py.
"""

from __future__ import annotations

import json
import logging
from typing import Any, Dict

from openai import OpenAI

from prompts import MODE_INSTRUCTIONS, SYSTEM_PROMPT

logger = logging.getLogger("jira_ai_engine.llm_engine")


class UnknownModeError(ValueError):
    pass


def _build_user_message(mode: str, payload: Dict[str, Any]) -> str:
    if mode not in MODE_INSTRUCTIONS:
        raise UnknownModeError(f"Unknown mode '{mode}'. Expected one of {list(MODE_INSTRUCTIONS)}.")

    instruction = MODE_INSTRUCTIONS[mode]
    data_json = json.dumps(payload, indent=2, default=str)

    return (
        f"{instruction}\n\n"
        f"Below is the current structured data pulled live from Jira "
        f"(Sprint Backlog Snapshot, Link Matrix, Issue History Logs, "
        f"Release Deadlines, Team Velocities). Apply the analytical rules "
        f"exactly as defined in your system prompt before writing the report.\n\n"
        f"```json\n{data_json}\n```"
    )


def generate_report(
    mode: str,
    payload: Dict[str, Any],
    api_key: str,
    model: str = "gpt-4.1",
    temperature: float = 0.3,
    max_output_tokens: int = 2000,
) -> str:
    """
    Sends the packaged payload to the LLM under the Agile Delivery
    Intelligence system prompt and returns the generated report text.
    """
    client = OpenAI(api_key=api_key)
    user_message = _build_user_message(mode, payload)

    logger.info(
        "Calling %s for mode=%s | backlog_items=%s | links=%s",
        model,
        mode,
        len(payload.get("sprint_backlog_snapshot", [])),
        len(payload.get("link_matrix", [])),
    )

    response = client.chat.completions.create(
        model=model,
        temperature=temperature,
        max_tokens=max_output_tokens,
        messages=[
            {"role": "system", "content": SYSTEM_PROMPT},
            {"role": "user", "content": user_message},
        ],
    )

    return response.choices[0].message.content
