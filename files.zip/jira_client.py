"""
jira_client.py
==============
Thin wrapper around the Jira Cloud REST API (v3). Responsible ONLY for
talking to Jira and returning raw JSON — no business logic lives here.
That keeps it easy to unit test and to swap for Jira Server/Data Center
(v2 API) by changing API_VERSION below.
"""

from __future__ import annotations

import logging
import time
from typing import Any, Dict, List, Optional

import requests
from requests.auth import HTTPBasicAuth
from tenacity import (
    retry,
    retry_if_exception_type,
    stop_after_attempt,
    wait_exponential,
)

logger = logging.getLogger("jira_ai_engine.jira_client")

API_VERSION = "3"  # use "2" for Jira Server / Data Center


class JiraAPIError(RuntimeError):
    """Raised when Jira returns a non-2xx response we can't recover from."""


class JiraClient:
    def __init__(self, base_url: str, email: str, api_token: str, timeout: int = 30):
        self.base_url = base_url.rstrip("/")
        self.timeout = timeout
        self.session = requests.Session()
        self.session.auth = HTTPBasicAuth(email, api_token)
        self.session.headers.update(
            {"Accept": "application/json", "Content-Type": "application/json"}
        )

    # ------------------------------------------------------------------
    # Low-level request helper with retry on transient failures / rate limits
    # ------------------------------------------------------------------
    @retry(
        reraise=True,
        stop=stop_after_attempt(5),
        wait=wait_exponential(multiplier=1, min=1, max=20),
        retry=retry_if_exception_type((requests.ConnectionError, requests.Timeout)),
    )
    def _request(self, method: str, path: str, **kwargs) -> requests.Response:
        url = f"{self.base_url}/rest/api/{API_VERSION}{path}"
        resp = self.session.request(method, url, timeout=self.timeout, **kwargs)

        if resp.status_code == 429:  # rate limited — honor Retry-After
            retry_after = int(resp.headers.get("Retry-After", "5"))
            logger.warning("Jira rate limit hit, sleeping %ss", retry_after)
            time.sleep(retry_after)
            resp = self.session.request(method, url, timeout=self.timeout, **kwargs)

        if not resp.ok:
            raise JiraAPIError(
                f"Jira API {method} {path} failed [{resp.status_code}]: {resp.text[:500]}"
            )
        return resp

    # ------------------------------------------------------------------
    # Issue search (paginated JQL)
    # ------------------------------------------------------------------
    def search_issues(
        self,
        jql: str,
        fields: Optional[List[str]] = None,
        page_size: int = 100,
        include_changelog: bool = True,
        max_issues: Optional[int] = None,
    ) -> List[Dict[str, Any]]:
        """
        Pull every issue matching `jql`, paginating through Jira's `startAt`
        cursor. When `include_changelog` is True, each issue's full status/
        flag transition history is expanded inline (needed for blocker aging
        and cycle time diagnostics) rather than requiring a second call per
        issue.
        """
        issues: List[Dict[str, Any]] = []
        start_at = 0
        expand = ["changelog"] if include_changelog else []

        while True:
            payload = {
                "jql": jql,
                "startAt": start_at,
                "maxResults": page_size,
                "fields": fields or ["*navigable"],
                "expand": expand,
            }
            resp = self._request("POST", "/search", json=payload)
            data = resp.json()

            batch = data.get("issues", [])
            issues.extend(batch)

            total = data.get("total", len(issues))
            logger.info("Fetched %s/%s issues", len(issues), total)

            start_at += len(batch)
            if not batch or start_at >= total:
                break
            if max_issues and len(issues) >= max_issues:
                issues = issues[:max_issues]
                break

        return issues

    # ------------------------------------------------------------------
    # Full changelog for a single issue (fallback path — normally the
    # `expand=changelog` on search above is sufficient and cheaper).
    # ------------------------------------------------------------------
    def get_issue_changelog(self, issue_key: str, page_size: int = 100) -> List[Dict[str, Any]]:
        histories: List[Dict[str, Any]] = []
        start_at = 0
        while True:
            resp = self._request(
                "GET",
                f"/issue/{issue_key}/changelog",
                params={"startAt": start_at, "maxResults": page_size},
            )
            data = resp.json()
            batch = data.get("values", [])
            histories.extend(batch)
            start_at += len(batch)
            if start_at >= data.get("total", len(histories)) or not batch:
                break
        return histories

    # ------------------------------------------------------------------
    # Release / fix-version deadlines, used for critical-path buffer math
    # ------------------------------------------------------------------
    def get_project_versions(self, project_key: str) -> List[Dict[str, Any]]:
        resp = self._request("GET", f"/project/{project_key}/versions")
        return resp.json()

    def get_project_versions_bulk(self, project_keys: List[str]) -> Dict[str, List[Dict[str, Any]]]:
        return {pk: self.get_project_versions(pk) for pk in project_keys}
