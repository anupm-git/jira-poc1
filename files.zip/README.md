# Agile Delivery Intelligence Engine — Prototype

A working implementation of the architecture in the diagram:

```
Python Script (Engine) ──1. JQL Query───────────▶ Jira API
                       ◀─2. Raw JSON Data────────
Python Script (Engine) ──3. System Prompt + Data─▶ LLM API (OpenAI)
                       ◀─4. Automated Text Report─
                       ─────▶ Output: Standup / Weekly Report / Slack
```

It pulls a live backlog from Jira (issues, transitions, blocker flags,
dependency links, release dates), reshapes it into the structured schema
the Agile Delivery Intelligence system prompt expects, and asks the LLM to
generate one of three reports.

## Files

| File | Responsibility |
|---|---|
| `jira_client.py` | Talks to the Jira REST API v3: paginated JQL search with changelog expansion, project versions. |
| `transformer.py` | Pure data-shaping — raw Jira JSON → Sprint Backlog Snapshot, Link Matrix, Issue History Logs, Release Deadlines, Team Velocities. |
| `prompts.py` | The system prompt and the Mode A/B/C user instructions, verbatim. |
| `llm_engine.py` | Packages the payload with the system prompt and calls the OpenAI Chat Completions API. |
| `main.py` | CLI orchestrator — wires the above together, writes the report, optionally posts to a Slack/Teams webhook. |
| `config.yaml` | JQL, field mappings, release projects, team velocities, LLM/output settings. |
| `.env.example` | Credential template (copy to `.env`). |

## Setup

```bash
pip install -r requirements.txt
cp .env.example .env      # then fill in your real credentials
```

Edit `config.yaml`:
- `jira.jql` — scope your backlog/program query.
- `jira.story_points_field` / `jira.team_field` — match your instance's
  custom field IDs (find them at `GET /rest/api/3/field`).
- `release_projects` — project keys whose Fix Versions should be treated
  as release deadlines.
- `team_velocities` — Jira's public REST API doesn't expose Agile velocity
  reports, so throughput is configured manually here (or swap in a call to
  `/rest/agile/1.0/board/{id}/velocity` in `transformer.build_team_velocities`
  if your plan/board exposes it).

## Run

```bash
python main.py --mode standup            # Mode A — daily standup bullets
python main.py --mode weekly             # Mode B — weekly program health
python main.py --mode retro              # Mode C — sprint-end retrospective
python main.py --mode standup --dry-run  # fetch + transform only, no LLM call, prints payload JSON
```

Each run writes a timestamped `.md` file to `reports/` and prints the
report to stdout. If `CHAT_WEBHOOK_URL` is set in `.env`, the report body
is also POSTed to that Slack/Teams incoming webhook (skip with
`--no-webhook`).

Schedule it with cron/CI (e.g. `0 9 * * 1-5 python main.py --mode standup`)
to fully automate the loop in the diagram.

## Extension points

- **Velocity from Jira Agile API**: replace `build_team_velocities` in
  `transformer.py` with a live board-velocity call if your plan supports it.
- **Financial impact on Blast Radius**: if Epics carry a dollar-value custom
  field, add it to `jira.fields` / `build_backlog_snapshot` so the LLM can
  compute financial blast radius as instructed in the system prompt.
- **Different LLM provider**: only `llm_engine._call` construction needs to
  change (e.g. swap `OpenAI(...)` for an Anthropic client) — `main.py` and
  `transformer.py` are provider-agnostic.
- **Jira Server/Data Center**: set `API_VERSION = "2"` in `jira_client.py`.
